Aha-soft ArtIcons Pro
Version: 5.24 (Build 2009-Feb-19)
Plattform: Windows 95/98/ME/NT/2000/XP/2003/Vista/Vienna.
Systemforderungen:
64MB RAM, Pentium-333 MHz, 4MB Festplatte, True Color Video Modus.

Aha-Soft ArtIcons Pro ist TRIAL-SOFTWARE.
Es ist eine leistungsstarke, easy-to-use Anwendung zum Finden, Extrahieren,
Erstellen und Bearbeiten der Icons und Verwalten der Iconbibliotheken.


Mit ArtIcons kann man:

* PNG-packed Windows Vista Icons erstellen und bearbeiten
* Icons im Bildformat in Standard- oder benutzerdefinierter Gr��e
 und in Farbtiefen bis zu 16 Millionen Farben erstellen und bearbeiten
* Icons f�r Windows XP in bis zu 32-Bit True Color Farbtiefen mit
 8-bit-Alpha-Kanal erzeugen und bearbeiten.
* Bilder, die einige Ebenen enthalten erstellen und lagern
* Bilder mit Farbverl�ufen und F�llmuster zeichnen
* Bilder modifizieren mit: Schatten, Opazit�t, Glattheit, Negativ, Grayscale,
  Kolorieren, Farbton/S�ttigung, Farbenersatz, Rotieren, Rollen und Spiegeln Effekte 
* ICO, ICPR, BMP, JPEG und PNG Bilder �ffnen und Bearbeiten
* Bilder zu ICO, ICPR, BMP, JPEG und PNG Dateien exportieren 
* Iconbibliotheken erstellen und verwalten
* Icons innerhalb Ausf�hrungs- und anderen Programmdateien modifizieren
* Icons aus Windows Ausf�hrungsdateien, Bibliotheken
und animierten Cursor-Dateien extrahieren 
* Icons aus allen Dateien in ausgew�hlten Ordner und Unterordner extrahieren
 und zu Iconbibliotheken speichern
* Identische Icons innerhalb der Bibliotheken L�schen
* Bilder innerhalb von Icons und Icons innerhalb der Bibliotheken ordnen
* Windows Desktop und Ordner-Icons bestimmen
* Dateien von Dateizellen ziehen und ablegen 
* Icons zwischen verschiedenen Bibliotheken ziehen und ablegen 
* Englisch, Spanisch, Deutsch Und andere Interfaces genie�en

Mit ArtIcons Pro kann man zus�tzlich:

* GIF, Adobe Photoshop PSD, WMF, XPM, XBM und WBMP Bilder,
  DCR und RES Dateien, CUR und ANI Cursor-Dateien importieren
* MAC OS Icons importieren
* Bilder zu GIF, Adobe Photoshop PSD, RC, XPM, XBM, WBMP
 und CUR Dateien exportieren
* Icon Farbpaletten im- und exportieren
* Mit Bildern in BMP und PNG Formate arbeiten
* Bibliothekeinheiten zum einzelnen Bild exportieren
* Iconbibliotheken in einzelne Icon-Dateien aufspalten
* Icons in Sub-Icons aufspalten 


Erh�ltliche Interfacesprachen:

Englisch, Bosnisch, Katalanisch, Chinesisch(BIG5), Chinesisch, Kroatisch, Tschechisch,
Niederl�ndisch, Franz�sisch, Deutsch, Ungarisch, Italienisch, Norwegisch, Polnisch,
Portugiesisch, Brasilianisch, Rum�nisch, Russisch, Serbisch (Cyr), Serbisch (Lat),
Spanisch, Schwedisch, T�rkisch, Ukrainisch.



Bewertungsversion Begrenzungen: 30-Tage lange Testperiode, Mahnungsfenster.


Die Letzte Programmausgabe kann von folgenden Seiten downloadet werden: 

http://www.iconutils.com/ger/download.htm,
http://www.aha-soft.com/ger/download.htm.



Copyright (C) 2000-2009, Aha-soft, All rights reserved
Unterst�tzungsseite: http://www.aha-soft.com/ger/support.htm
Produktseite: http://www.aha-soft.com/ger/articons/index.htm
Bestellseite: http://www.aha-soft.com/ger/articons/reg.htm
Mirror site: http://iconutils.com